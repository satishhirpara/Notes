1) Create data base with name 'Satish_Test' in sql server.
2) open table creation script from below path and execute it.
   'Satish_MyTest\DB Scripts\Tables with Data.sql'
3) Now open solution and go to Satish_MyTest.DAL > MyDbContent.edmx file.
   update edmx file and connection string (web .config) with your sql server's 
   connection string.
4) Now simply build and run the project.

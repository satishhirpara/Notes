﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Satish_MyTest.DAL;
using Satish_MyTest.DAL.Interfaces;
using System.Threading.Tasks;

namespace Satish_MyTest
{
    public partial class _Default : Page
    {

        NoteRepository noterepository = new NoteRepository(new MyDbContext());

        public long NoteId
        {
            get
            {
                long result = 0;
                long.TryParse(Convert.ToString(ViewState["NoteId"]), out result);
                return result;
            }
            set
            {
                ViewState["NoteId"] = value;
            }
        }
        public long UserId
        {
            get
            {
                long result = 0;
                long.TryParse(Convert.ToString(Session["UserId"]), out result);
                return result;
            }
            set
            {
                Session["UserId"] = value;
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                BindGrid();
            }
        }

        protected void btnSave_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                SaveData();
            }
            else
            {
                FailureText.Text = "Invalid input.";
                ErrorMessage.Visible = true;
            }
        }
        protected void lnkEdit_Click(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            this.NoteId = long.Parse((item.FindControl("lblNoteId") as Label).Text);
            //var userId = long.Parse((item.FindControl("lblNoteId") as Label).Text);

            var noteTbl = GetNote();
            if (noteTbl == null)
            {
                FailureText.Text = "Note not found.";
                ErrorMessage.Visible = true;
                return;
            }

            SetControls(noteTbl);
        }
        protected void lnkDelete_Click(object sender, EventArgs e)
        {
            RepeaterItem item = (sender as LinkButton).Parent as RepeaterItem;
            this.NoteId = long.Parse((item.FindControl("lblNoteId") as Label).Text);
            DeleteNote();
        }
        protected void btnCancel_Click(object sender, EventArgs e)
        {
            ClearControls();
        }

        private void ClearControls()
        {
            txtTitle.Text = "";
            txtBody.Text = "";
            this.NoteId = 0;
        }
        private NoteTbl bindobject()
        {
            NoteTbl _note = new NoteTbl();
            _note.notesid = this.NoteId;
            _note.userid = this.UserId;
            _note.title = txtTitle.Text.Trim();
            _note.body = txtBody.Text.Trim();
            return _note;
        }
        private void SetControls(NoteTbl note)
        {
            this.NoteId = note.notesid;
            txtTitle.Text = note.title;
            txtBody.Text = note.body;
        }

        private void BindGrid()
        {
            var notes = noterepository.GetNotes(this.UserId);
            if (notes != null)
            {
                rptNotes.DataSource = notes;
                rptNotes.DataBind();

            }
            ClearControls();
        }
        private NoteTbl GetNote()
        {
            return noterepository.GetNoteById(this.NoteId);
        }
        private void SaveData()
        {
            NoteTbl note = bindobject();
            if (this.NoteId == 0)
            {
                noterepository.PostNote(note);
            }
            else
            {
                noterepository.PutNote(note);
            }

            BindGrid();
        }
        private void DeleteNote()
        {
            noterepository.DeleteNote(this.NoteId);
            BindGrid();
        }

    }
}
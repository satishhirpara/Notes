﻿using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System;
using System.Linq;
using System.Web;
using System.Web.UI;
using Satish_MyTest.Models;
using Satish_MyTest.DAL;
using System.Web.Security;

namespace Satish_MyTest
{
    public partial class LogIn : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            if (IsValid)
            {
                // Validate the user password
                var iUserRepository = new UserRepository(new MyDbContext());
                var user = iUserRepository.Get(UserName.Text, Password.Text);
                if (user.Result != null)
                {
                    Session["UserId"] = user.Result.userid.ToString();
                    
                    FormsAuthentication.SetAuthCookie(UserName.Text, false);
                    Response.Redirect("Default.aspx");
                }
                else
                {
                    FailureText.Text = "Invalid username or password.";
                    ErrorMessage.Visible = true;
                }
            }
        }

    }
}
﻿using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Satish_MyTest
{
    public partial class SiteMaster : MasterPage
    {

        protected override void OnInit(EventArgs e)
        {
            if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
            {
                if (Session["UserId"] == null)
                {
                    Response.Redirect("Login.aspx", false);
                }
            }
            else
            {
                Response.Redirect("Login.aspx", false);
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            //if (System.Web.HttpContext.Current.User.Identity.IsAuthenticated)
            //{
            //    if (!IsPostBack)
            //    {

            //    }
            //}
            //else
            //{
            //    Response.Redirect("Login.aspx", false);
            //}
        }

        protected void lnkLogout_Click(object sender, EventArgs e)
        {
            FormsAuthentication.SignOut();
            Session.Clear();  // This may not be needed -- but can't hurt
            Session.Abandon();

            Response.Redirect("Login.aspx", false);
        }

    }

}
﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Satish_MyTest.Startup))]
namespace Satish_MyTest
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}

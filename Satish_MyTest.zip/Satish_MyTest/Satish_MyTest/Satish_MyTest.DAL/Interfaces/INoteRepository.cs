﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Satish_MyTest.DAL.Interfaces
{
    public interface INoteRepository : IDisposable
    {
        List<NoteTbl> GetNotes(long userId);
        NoteTbl GetNoteById(long id);
        void PostNote(NoteTbl note);
        void DeleteNote(long id);
        void PutNote(NoteTbl note);
    }
}

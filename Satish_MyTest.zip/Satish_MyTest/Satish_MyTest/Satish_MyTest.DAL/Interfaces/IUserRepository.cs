﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Satish_MyTest.DAL.Interfaces
{
    public interface IUserRepository : IDisposable
    {
        Task<UserTbl> Get(string username, string password);
    }
}

﻿using Satish_MyTest.DAL.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace Satish_MyTest.DAL
{
    public class NoteRepository : INoteRepository, IDisposable
    {
        private MyDbContext context;

        public NoteRepository(MyDbContext _context)
        {
            context = _context;
        }

        public void PostNote(NoteTbl note)
        {
            context.NoteTbls.Add(note);
            context.SaveChanges();
        }
        public void DeleteNote(long id)
        {
            NoteTbl note =  context.NoteTbls.Find(id);
            context.NoteTbls.Remove(note);
            context.SaveChanges();
        }
        public void PutNote(NoteTbl note)
        {
            context.Entry(note).State = EntityState.Modified;
            context.SaveChanges();
        }

        public NoteTbl GetNoteById(long id)
        {
            NoteTbl note = context.NoteTbls.Find(id);
            return note;
        }
        public List<NoteTbl> GetNotes(long userId)
        {
            return context.NoteTbls.Where(k => k.userid == userId).ToList();
        }
        public NoteTbl GetNoteById(long? id)
        {
            return context.NoteTbls.Find(id);
        }

        #region Dispose methods

        private bool disposedValue = false; // To detect redundant calls
        protected virtual void Dispose(bool disposing)
        {
            if (!disposedValue)
            {
                if (disposing)
                {
                    // TODO: dispose managed state (managed objects).
                    context.Dispose();
                }

                // TODO: free unmanaged resources (unmanaged objects) and override a finalizer below.
                // TODO: set large fields to null.

                disposedValue = true;
            }
        }

        // TODO: override a finalizer only if Dispose(bool disposing) above has code to free unmanaged resources.
        // ~NoteRepository() {
        //   // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
        //   Dispose(false);
        // }

        // This code added to correctly implement the disposable pattern.
        public void Dispose()
        {
            // Do not change this code. Put cleanup code in Dispose(bool disposing) above.
            Dispose(true);
            // TODO: uncomment the following line if the finalizer is overridden above.
            // GC.SuppressFinalize(this);
            GC.SuppressFinalize(this);
        }

        #endregion

    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Satish_MyTest.DTO
{
    public partial class userDTO
    {
        public userDTO()
        {
            this.notes = new HashSet<noteDTO>();
        }

        public long userid { get; set; }
        public string username { get; set; }
        public string password { get; set; }

        public ICollection<noteDTO> notes { get; set; }
    }
}

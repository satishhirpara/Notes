﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Satish_MyTest.DTO
{
    public partial class noteDTO
    {
        public long notesid { get; set; }
        public Nullable<long> userid { get; set; }
        public string note1 { get; set; }

        public userDTO user { get; set; }
    }
}
